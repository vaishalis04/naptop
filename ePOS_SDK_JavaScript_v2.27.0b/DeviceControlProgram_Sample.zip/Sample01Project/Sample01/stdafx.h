#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include "GGateway.h"	/*Include before windows.h*/
#include <windows.h>
