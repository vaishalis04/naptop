const cron = require('node-cron')
// const { inactiveUser } = require('../Scripts/routine_executions')

// cron.schedule('0 30 5 * * *', async () => {
//     try {
//         const result = await inactiveUser()
//     } catch (error) {
//         console.log(error);
//     }
// })